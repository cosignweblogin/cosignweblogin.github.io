<?php
/**
 * Main index script for the Tools List application
 *
 * @package tools_list
 */

/**
 * Autoload classes
 *
 * Special function that is called when a new class instance is
 * created. It loads the script that defines the class.
 *
 * @param string $class_name 
 */
function __autoload($class_name) {
/* CHECK VALUE: */
  $class_file = '../classes/'.$class_name.'.class.php';

  if (file_exists($class_file)) require_once($class_file) ;
  else return false;
}

// Create an instance of the Directory_Groups class and define the ini
// file section that overrides #tools_list directives. Then populate
// the tools property by calling the parse_htaccess_files method.
$get_tools = new Directory_Groups();
$get_tools->ini_file_section = 'application';
/* CHECK VALUE: */
$get_tools->doc_root = '/Library/WebServer/Documents'; 
$get_tools->parse_htaccess_files();

// Create an instance of the Membership class and define the LDAP
// server's hostname and the user and group bases. Then create the
// connection and bind to the LDAP server with the create_connection
// method. Membership can be tested with the is_member method.
$member = new Membership();
/* CHECK VALUE: */
$member->ldap_hostname = 'ldap.itd.umich.edu';
/* CHECK VALUE: */
$member->user_base     = 'ou=People,dc=umich,dc=edu';
/* CHECK VALUE: */
$member->group_base    = 'ou=User Groups,ou=Groups,dc=umich,dc=edu';
$member->create_connection();

// Create an instance of the Template class and define the directory
// that holds the templates.
$template = new Template();
/* CHECK VALUE: */
$template->dir = '../templates'; 

$uniqname = $_SERVER['REMOTE_USER'];

// Loop through groups for each tool and test for membership. If the
// user is a member of one of the groups listed add data to the
// links_array.
foreach ($get_tools->tools as $tool) {
  if ($tool['groups']) {
    foreach ($tool['groups'] as $group) {
      if ($member->is_member($uniqname, $group)) {
	if ($tool['url'] or $tool['urls']) {
	  $link_array[]=array('title' => $tool['title'], 'url' => $tool['url'], 'urls' => $tool['urls'], 'groups' => $tool['groups']);
	}
      }
    }
  }
}

// Assign $links_array to the template variable space. Then display the template.
$template->assign('links', $link_array);
$template->display('tools_list');
?>