<?php
/**
 * This script defines the Member class.
 *
 * @package tools_list
 */

/**
 * Determine group membership
 * 
 * The Member class establishes a connection to the LDAP server and
 * provides the is_member() method.
 *
 * To initialize this class create a new instance, define the
 * necessary properties, call the create_connection() method, then use
 * the is_member() method. For example:
 *
 * <code>
 * $member = new Membership();
 * $member->ldap_hostname = 'ldap.itd.umich.edu';
 * $member->user_base     = 'ou=People,dc=umich,dc=edu';
 * $member->group_base    = 'u=User Groups,ou=Groups,dc=umich,dc=edu';
 * $member->create_connection();
 *
 * if ($member->is_member($uniqname, $group_name)) {
 *   echo $uniqname.' is a member of '.$group_name.'!';
 * }
 * </code>
 *
 * @package tools_list
 */
class Membership {
  /**
   * @var string $ldap_hostname The hostname of the LDAP server to
   * connect to.
   */
  public $ldap_hostname ;
  /**
   * @var string $ldap_connection The connection resource provided by
   * ldap_connect(). Used by the is_member() method.
   */
  protected $ldap_connection;
  /**
   * @var string $user_base The users base, for example
   * 'ou=People,dc=umich,dc=edu'
   */
  public $user_base ;
  /**
   * @var string $group_base The groups base, for example 'ou=User
   * Groups,ou=Groups,dc=umich,dc=edu'
   */
  public $group_base ;

  /**
   * If the $ldap_hostname property is defined, connect to it.
   */
  public function create_connection() {
    if ($this->ldap_hostname) {
      if (! $this->ldap_connection = ldap_connect($this->ldap_hostname)) return false; // fail if connection fails
      if (! ldap_bind($this->ldap_connection)) return false; // fail if bind fails
    } else {
      return false; // fail if $ldap_hostname is not defined
    }
  }
  
  /**
   * If the LDAP connection is established, close it.
   */
  public function __destruct() {
    if ($this->ldap_connection) {
      ldap_close($this->ldap_connection);
    }
  }
  
  /**
   * Test for membership
   *
   * Uses the connection to the LDAP server created by the
   * create_connection() method. Returns true only if the query
   * succeeds and if the specified user is a member of the specified
   * group. The method returns false if the query fails or if the user
   * is not a member of the group.
   *
   * @return boolean
   * @param string $user 
   * @param string $group 
   */
  public function is_member($user, $group) {
    $base_dn = 'cn='.$group.','.$this->group_base; 
    $filter  = 'member=uid='.$user.','.$this->user_base;
    // echo 'base_dn: '.$base_dn.'<br />'."\n";
    // echo 'filter: '.$filter.'<br />'."\n";
    if ($this->ldap_connection) {
      if (! $search_result=ldap_search($this->ldap_connection, $base_dn, $filter) ) return false; // fail if search fails
      if (! $entries = ldap_get_entries($this->ldap_connection, $search_result)) return false; // fail if getting entries fails
      if ($entries['count'] == 1) {
	return true; // succeed if an entry was found 
      } else {
	return false; // fail if no entry was found
      }
    } else {
      return false; // fail if there is no LDAP connection
    }
}
}
?>