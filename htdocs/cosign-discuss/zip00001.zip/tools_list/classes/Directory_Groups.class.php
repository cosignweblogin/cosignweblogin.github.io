<?php
/**
 * This script defines the Directory_Groups class
 *
 * @package tools_list
 */

/**
 *
 *
 */
class Directory_Groups {
  /**
   * @var array $tools
   */
  public $tools;
  
  /**
   * @var string INI file section name
   */
  public $ini_file_section = 'tools_list';

  /**
   * @var string $doc_root Path to the Document Root. Location to
   * begin recursively searching for .htaccess files.
   */
  public $doc_root ;

  /**
   * Parse .htaccess files
   *
   * Parses the .htaccess files found in the path defined by the
   * $doc_root property. This method populates the $tools property
   * with an array for each .htaccess file. Each array defines the
   * groups that are required for each directory (as defined by the
   * Require group directive) also any values set by the tools_list
   * pseudo-directive.
   *
   */
  public function parse_htaccess_files() {
    // yeah, yeah. but it's easy...
    exec('/usr/bin/find -L '.$this->doc_root.' -name ".htaccess" -print', $htaccess_files, $return_value);
    if ($return_value != 0) return false ; // fail if the find command fails
    $i = 0;
    foreach ($htaccess_files as $ht_file) {
      $ht_file_contents = file($ht_file);
      foreach ($ht_file_contents as $line) {
	$line_parts = explode(' ', trim($line));
	$line_first = array_shift($line_parts);
	switch ($line_first) {
	case 'Require': 
	  if ($line_parts[0] == 'group') {
	    $line_second = array_shift($line_parts);
	    $this->tools[$i]['groups'] = $line_parts;
	  }
	  break;
	case '#tools_list':
	  if ($line_parts[0] and $line_parts[1]) { // if the tools_list "sub-pseudo-directive" exists, proceed
	    $tools_list_directive = array_shift($line_parts);
	    $tools_list_value = implode(' ', $line_parts);
	    switch ($tools_list_directive) {
	    case 'ini_path': 
	      if (file_exists($tools_list_value)) {
		// if the ini_path exists and is a valid file, parse it with parse_ini_file()
		$ini_file_array = parse_ini_file($tools_list_value, true);
		// echo '<pre style="color: red;">'; print_r($ini_file_array); echo '</pre>';
		foreach ($ini_file_array[$this->ini_file_section] as $key => $value) {
		  $this->tools[$i][$key] = $value;
		  
		}
	      }
	      break;
	    case 'urls':
	      $this->tools[$i]['urls'] = explode(' ', $tools_list_value);
	      break;
	    default:
	      // Only set the keys and values if they haven't been set from the ini file.
	      if ((! $this->tools[$i][$tools_list_directive]) and ($tools_list_directive != 'ini_path')) {
		$this->tools[$i][$tools_list_directive] = $tools_list_value;
	      }
	      break;
	    }  
	  }
	  break;
	}
      }
      $i++;
    }
  }
}
?>