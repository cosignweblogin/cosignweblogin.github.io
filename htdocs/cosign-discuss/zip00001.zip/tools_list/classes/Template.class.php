<?php
/**
 * This script defines the Template class
 *
 * @package tools_list
 */

/**
 * Provides templating system
 *
 * This class is largely inspired by the article "Template Engines" by
 * Brian Lozier (URL below). Although this class is much more basic in
 * its implemetation.
 *
 * @see http://www.massassi.com/php/articles/template_engines/
 * @package tools_list
 */
class Template {
  /**
   * @var array $vars Holds variables for the template
   */
  public $vars ;
  /**
   * @var string $dir Path to the directory where templates are stored.
   */
  public $dir ;

  /**
   *@var string $ext The exention to be used on the template name given to the display() method.
   */
  public $ext  = '.template.php';

  /**
   * Displays the given template
   *
   * Extracts the variables from the $vars property. In the case of a
   * collision with an existing variable name, the variable name from
   * the $vars array will be prefixed with the string "template_".
   *
   * Then includes the $template_file, thereby displaying it.
   *
   * @param string $template_file Path to the template to display 
   * @see http://www.php.net/manual/en/function.extract.php
   */
  public function display($template_file) {
    if ($this->vars) {
      extract($this->vars, EXTR_PREFIX_SAME, 'template_'); 
    }
    include $this->dir.'/'.$template_file.$this->ext;
  }

  /**
   * Assign values to template variables.
   *
   * @param string $name Name of the variable to be used in the template.
   * @param string $value Value of the variable to be used in the template.
   */
  public function assign($name, $value) {
    $this->vars[$name] = $value;
  }

}
?>