<html>
<head>
  <link rel="stylesheet" type="text/css" href="/common/style/tools.css" />
  <title>Tools List</title>
</head>
<body>
<?php if ($links) { ?>
  <div class="logout"><a href="/logout.php">LOGOUT</a></div>
  <h1>Tools List</h1>
  <p>This is a list of the tools you have access to on this server:</p>
  <ul>
<?php foreach ($links as $link) { 
  unset($group_list);
  foreach ($link['groups'] as $group) { $group_list .= $group.' ' ;}
  trim($group_list);
  if ($link['urls']) { ?>
    <li><?php echo $link['title'].' ('.$group_list.')'; ?>
      <ul>
<?php foreach ($link['urls'] as $url) {?>
        <li><a href="<?php echo $url; ?>"><?php echo $url ?></a></li>
<?php } ?>
      </ul>
<?php  continue; } if (! $link['title']) $link['title'] = $link['url'] ; ?>
    <li><a href="<?php echo $link['url']; ?>"><?php echo $link['title']; ?></a> <?php echo ' ('.$group_list.') '; ?></li>
<?php } ?>
  </ul>
<?php } else { ?>
  <p>You do not appear to have access to the tools on this server. If you believe should not be getting this message, please contact the UHS ITS Help Desk at UHSHelpDesk@umich.edu</p>
<?php } ?>
</body>
</html>
