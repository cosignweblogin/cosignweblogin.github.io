<html>
<head>
  <link rel="stylesheet" type="text/css" href="/common/style/tools.css" />
  <title>Tools List</title>
</head>
<body>
<?php if ($links) { ?>
  <div class="logout"><a href="/logout.php">LOGOUT</a></div>
  <h1 style="margin-top: 0px;">Tools List</h1>
  <p>This is a list of the tools you have access to on this server:</p>
  <ul>
<?php foreach ($links as $link) { 
   if (! $link['title']) $link['title'] = $link['url'] ; ?>
    <li><a href="<?php echo $link['url']; ?>"><?php echo $link['title']; ?></a></li>
<?php } ?>
  </ul>
<?php } else { ?>
  <p>You do not appear to have access to the tools on this server. If you believe should not be getting this message, please contact the UHS ITS Help Desk at UHSHelpDesk@umich.edu</p>
<?php } ?>
</body>
</html>
